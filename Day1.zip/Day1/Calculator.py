mick = 3.5
alice = 2.5
total = (mick + alice) * 60 * 60
print("Mick took ", mick, "hr")
print("Alice took", alice, "hr")
print("Total time is", total, "s")

