def test_func(a,b):
	my_list=[]
	return (a,b,my_list)

a=0
b=0
x, y, tmp_list = test_func(a,b)

