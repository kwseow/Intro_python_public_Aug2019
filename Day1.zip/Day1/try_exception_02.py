try:
  5/0
finally:
  print("Oops, just before we run into an exception.")
  
