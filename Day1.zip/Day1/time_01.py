import time

print(time.strftime("Today is %d-%m-%Y %H:%M", time.localtime()))

