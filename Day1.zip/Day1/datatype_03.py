my_list = [1,2,3]
print (my_list)
# [1,2,3]

print(my_list[0])
# 2

print(my_list[2])
# 

print(my_list[3])
# error!