s = "hello"
t = "world"
print (s + " " + t)
# hello world

s = "123"
print(s * 4)
# 123123123123

print(s + 4)
# error!