i = 3.0
print(type(i))

i = 3
print(type(i))

print(i/2)

print(i//2)
