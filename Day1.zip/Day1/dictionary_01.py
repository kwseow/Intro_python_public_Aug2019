scores = {"Mary":90, "Ben":67, "Jenny":21}
for s in scores:
  print(s)

