word = input("Enter a word:")
# script will stop here and wait for user to enter a word
print(word, "is ", type(word))
# Seow is  <class 'str'>

num = input("Enter a whole number: ")
print(num, "is ", type(num))
#10 is  <class 'str'>

num = int(num)
print(num, "is ", type(num))
# 10 is  <class 'int'>