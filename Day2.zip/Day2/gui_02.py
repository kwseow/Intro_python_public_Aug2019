import tkinter

window = tkinter.Tk()

#Add a button
button = tkinter.Button(window, text="Start")
button.pack()

window.mainloop()

